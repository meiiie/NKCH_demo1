﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication3.Controllers
{
    public class CuocBauCuController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
