﻿//using System;
//using System.Collections.Generic;

//namespace WebApplication3.Models;

//public partial class PhienDangNhap
//{
//    public string Id { get; set; } = null!;

//    public int TaiKhoanId { get; set; }

//    public string DuLieuPhien { get; set; } = null!;

//    public DateTime NgayHetHan { get; set; }

//    public virtual TaiKhoan TaiKhoan { get; set; } = null!;
//}
