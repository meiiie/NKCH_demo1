﻿namespace WebApplication3.Models
{
    public class LoginDTO
    {
        public string TenDangNhap { get; set; }
        public string MatKhau { get; set; }
    }
}
