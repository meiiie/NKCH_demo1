﻿using System;
using System.Collections.Generic;

namespace WebApplication3.Models;

public partial class VKetQuaPhienBauCu
{
    public int? PhienBauCuId { get; set; }

    public int UngCuVienId { get; set; }

    public int? SoPhieu { get; set; }
}
